title: 《C++从入门到精通》
date: '2020-10-17 09:43:32'
updated: '2020-10-17 12:32:02'
tags: [C++]
permalink: /articles/2020/10/17/1602899012298.html
---
![在这里插入图片描述](https://img-blog.csdnimg.cn/20201017094158842.jpg?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2hlaWZlbmdsaTY2NjY=,size_16,color_FFFFFF,t_70#pic_center)

# 《C++从入门到精通》学习笔记

## 随书资料

扫码自取

![在这里插入图片描述](https://img-blog.csdnimg.cn/2020101709455050.jpg?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2hlaWZlbmdsaTY2NjY=,size_16,color_FFFFFF,t_70#pic_center)

## 知识学习

## 习题实战

#### 6.6.2蜗牛爬井

题目：

> 有一口井深10m，一只蜗牛从井底向井口爬，白天向上爬2m，晚上向下滑1m，问多少天可以爬到井口？

分析：

> 白天爬完2m时增加判断条件，到达10m直接输出所耗天数

代码实现：

```cpp
#include <iostream>
using namespace std;
 #define J 10

int Day()
{
	for (int i = 0,j = 1;;j++)
	{
		i = i + 2;
		if (i >= J) return j;
		i = i - 1;
	}
}


int main()
{

	int n =Day();

	cout << "第" << n << "天爬到井口" << endl;



	system("pause");
	return 0;
}
```

![在这里插入图片描述](https://img-blog.csdnimg.cn/20201017122953663.jpg?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2hlaWZlbmdsaTY2NjY=,size_16,color_FFFFFF,t_70#pic_center)

#### 7.8.1模拟生兔子

题目：

> 设一对大兔子每月生一对小兔子，每对新生兔在出生一个月后又下崽，假若兔子都不死亡。问：一对兔子一年能繁殖成多少对兔子？

分析：

> 第一个月：两只大兔子											2
> 第二个月：两只大兔子+两只小兔子						4
> 第三个月：四只大兔子+两只小兔子						6	
> 第四个月：六只大兔子+四只小兔子					   10
> .......
> 由此可得：第n月兔子数为=第n-1月兔子数量+第n-2月兔子数量

代码实现：

```cpp
#include <iostream>
using namespace std;
 int num = 2;
 int month = 0;
int func(int n)
{
	if (n == 1) return 2;
	if (n == 2) return 4;
	num = func(n - 1) + func(n - 2);
	return num;
}

int main()
{

	cout << "请输入月份：";
	cin >> month;
	
	func(month);

	cout << "第" << month << "月的兔子数量为：" << num / 2 << endl;

	system("pause");
	return 0;
}
```

![在这里插入图片描述](https://img-blog.csdnimg.cn/2020101710440444.jpg?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2hlaWZlbmdsaTY2NjY=,size_16,color_FFFFFF,t_70#pic_center)

