title: 《C++从零开始学》---王英英
date: '2020-10-03 09:39:19'
updated: '2020-10-05 18:18:40'
tags: [C++]
permalink: /articles/2020/10/03/1601689159093.html
---
![IMG20201003093205.jpg](https://b3logfile.com/file/2020/10/IMG20201003093205-1eca7c22.jpg)

<center><iframe scrolling="no" src="https://datealive.top/IP-master/index.php" frameborder="0"
width="356" height="240" allowtransparency="true"></iframe></center>

# 弃坑黑马程序员C++

纸上得来终觉浅，之前一直看着黑马程序员的视频，一边看一边敲，敲了两个星期，感觉自己只会跟着老师敲，脑子动的太少了，进步不明显，感觉这种方式不适合我

于是弃坑去图书馆借了本实体书开始对着学

# 《C++从零开始学》---王英英

### 随书资料

扫码自取

![IMG20201003093200.jpg](https://b3logfile.com/file/2020/10/IMG20201003093200-9047f405.jpg)

里面有视频讲解+随书源代码+课程PPT

# 该书学习笔记

#### 命名空间

引入命名空间是为了解决不同模块（函数）下相同标识符冲突的问题，提高标识符的利用率

```
#include <iostream>
#include <string>
using namespace std;
namespace myown1 {
	string user_name = "myown1";
}
namespace myown2 {
	string user_name = "myown2";
}
//两个在不同命名空间中定义的名字相同的变量
int main() 
{
	cout << "Hello, "
		<< myown1::user_name//用命名空间限制符myown1访问变量user_name
		<< endl;
	cout << "Hello, "
		<< myown2::user_name//用命名空间限制符myown2访问变量user_name
		<< endl;

	




	system("pause");
	return 0;
}
```

![2.7.1.jpg](https://b3logfile.com/file/2020/10/2.7.1-196644aa.jpg)

#### 求解一元二次方程ax^2+bx+c=0的根

```
#include <iostream>
#include <string>
//常用数学工具库
//官方网址       http://www.cplusplus.com/reference/cmath/
#include <cmath>
using namespace std;
//求解一元二次方程ax^2+bx+c=0的根
int main()
{
	float a, b, c;//系数
	float x1, x2;
	cout << "请输入a的值：" << endl;
	cin >> a;
	cout << "请输入b的值：" << endl;
	cin >> b;
	cout << "请输入c的值：" << endl;
	cin >> c;
	cout << "您输入的方程为：" << a << "x^2+" << b << "x+" << c << "=0" << endl;

	float t = b * b - 4 * a * c;//得塔
	if (t < 0) 
	{
		cout << "此方程无实数根" << endl;
	}
	else
	{
		//求根公式
		x1 = (-b + sqrt(t)) / (2 * a);//sqrt(t):对t开平方
		x2 = (-b - sqrt(t)) / (2 * a);

		cout << "一个根x1=" << x1 << endl;
		cout << "一个根x2=" << x2 << endl;
	}



	system("pause");
	return 0;
}
```

![2.7.2.jpg](https://b3logfile.com/file/2020/10/2.7.2-06b4a92d.jpg)

#### 判断输入的一个字符是否为大写

判断输入的一个字符是否为大写
若是：转化成小写
若不是：原样输出

```
#include <iostream>
using namespace std;

//判断输入的一个字符是否为大写
//若是：转化成小写
//若不是：原样输出
int main()
{
	////获取a和A的ASCII码
	//char ASC_a = 'a';
	//cout << (int)ASC_a << endl;//a的ASCII码为：97

	//char ASC_A = 'A';
	//cout << (int)ASC_A << endl;//A的ASCII码为：65

	//将字符类型char前面加上（int）强制转换成整型即可得到该字符的ASCII码

	char x;
	cout << "请输入需要判断的字符：" << endl;
	cin >> x;
	
	(int)x >= 65 && (int)x<=96 ? 
		cout << "此字符为大写字母，转化成小写字母"<<char((int)x+32)<< endl :
	    cout << "此字符为小写字母" << x << endl;



	system("pause");
	return 0;


}
```

![2.7.4.jpg](https://b3logfile.com/file/2020/10/2.7.4-6124aa0f.jpg)

#### 判断某一年是否是闰年

闰年的条件是：1.能被4整除而不能被100整除   2.同时能被100和400整除

```
#include <iostream>
using namespace std;

//判断某一年是否是闰年
//闰年的条件是：1.能被4整除而不能被100整除   2.同时能被100和400整除

int main()
{
	cout << "请输入要判断的年份：" << endl;
	int x = 0;
	cin >> x;

	if (x % 4 == 0 && x % 100 != 0) 
	{
		cout <<x<< "年为闰年！" << endl;
	}
	else if (x % 100 == 0 && x % 400 == 0)
	{
		cout << x << "年为闰年！" << endl;
	}
	else
	{
		cout << x << "年不是闰年！" << endl;
	}



	system("pause");
	return 0;


}
```

![2.7.5.jpg](https://b3logfile.com/file/2020/10/2.7.5-8c76cb09.jpg)

#### 反向输出

从键盘上读取4个字符，把它们放在一个4字节的整型变量中，把这个变量的值显示为一个16进制；分解变量的4个字节，以相反的顺序输出它们，先输出低位字节

```
#include <iostream>
using namespace std;


//从键盘上读取4个字符，把它们放在一个4字节的整型变量中，把这个变量的值显示为一个16进制
//分解变量的4个字节，以相反的顺序输出它们，先输出低位字节
int main()
{
	cout << "请输入4个字符" << endl;
	char a[4];
	cin >> a[0] >> a[1] >> a[2] >> a[3] ;
	////输出测试----是否接收成功
	//for (int i = 0;i < 4;i++)
	//{
	//	cout << a[i] << endl;
	//}
	int x;
	x = (int)a[0]*1000+ (int)a[1] * 100+ (int)a[2] * 10+(int)a[3];

	cout << hex <<"转成十六进制为：" <<x << endl;//通过hex输出16进制数

	cout <<  a[3] 
		<< a[2]
		<< a[1]
		<< a[0]
		<< endl;

	system("pause");
	return 0;


}
```

![2.7.6.jpg](https://b3logfile.com/file/2020/10/2.7.6-9b1a5146.jpg)

#### 利用三角形三条边求三角形面积

```
#include <iostream>
#include <cmath>
using namespace std;


//输入三角形的三条边长，计算三角形的面积
int main()
{
	float a, b, c, s, area;
	cout << "请输入第一条边的长度：" << endl;
	cin >> a;
	cout << "请输入第二条边的长度：" << endl;
	cin >> b;
	cout << "请输入第三条边的长度：" << endl;
	cin >> c;
	//判断是否可以构成三角形
	if (a + b > c && a + c > b && b + c > a) 
	{
		//海伦公式
		s = (a + b + c) / 2;
		area = sqrt(s * (s - a) * (s - b) * (s - c));
		cout << "此三角形面积为：" << area << endl;
	}
	else {
		cout << "此三条边构不成三角形！" << endl;
	}
	


	system("pause");
	return 0;


}
```

![2.7.7.jpg](https://b3logfile.com/file/2020/10/2.7.7-b8680978.jpg)

#### 求解自然对数e

自然对数e的计算公式为：
e=1+1/1!+1/2!+1/3!+1/4!+...+1/n!+r
当n充分大时，可计算e的近似值 其中r为误差

```
#include <iostream>
using namespace std;

#define EPX 0.1e-10 //设置最小误差为0.1^-10

//自然对数e的计算公式为：
//e=1+1/1!+1/2!+1/3!+1/4!+...+1/n!+r
//当n充分大时，可计算e的近似值 其中r为误差
int main()
{
	int n = 1;
	double e = 1, r = 1;
	do {
		e = e + r;
		n++;
		r = r / n;

	} while (r > EPX);
	cout <<"自然对数的近似值为：" << e << endl;
	system("pause");



}
```

![2.7.8.jpg](https://b3logfile.com/file/2020/10/2.7.8-306523e1.jpg)

#### 递归调用求解数组

现有一个数列，已知an=2*a(n-1)+3,并且a1=1，求解a1～a10的值

```
#include <iostream>
using namespace std;

int f(int a) {
	if (a == 1) {
		return 1;
	}
	else 
	{ 
		a = 2 * f(a-1)  + 3; 
	}
	return a;
}


//现有一个数列，已知an=2*a(n-1)+3,并且a1=1，求解a1～a10的值
int main()
{
	//测试输出
	//cout << f(2) << endl;

	for (int i = 1;i < 11;i++)
	{
		cout << f(i) << endl;
	}



	system("pause");
	return 0;


}
```

![6.3.1.jpg](https://b3logfile.com/file/2020/10/6.3.1-a8da4fe2.jpg)

#### 汉诺塔问题

汉诺塔问题：
汉诺塔来源于印度传说的一个故事，大梵天创造世界时作了三根金刚石柱子，在一根柱子上从上往下从小到大顺序摞着64片黄金圆盘。上帝命令婆罗门把圆盘从下面开始按大小顺序重新摆放在另一根柱子上。并且规定，在小圆盘上不能放大圆盘，在三根柱子之间一回只能移动一个圆盘，只能移动在最顶端的圆盘。

```
#include <iostream>
using namespace std;


//汉诺塔问题
//汉诺塔来源于印度传说的一个故事，大梵天创造世界时作了三根金刚石柱子，
//在一根柱子上从上往下从小到大顺序摞着64片黄金圆盘。
//上帝命令婆罗门把圆盘从下面开始按大小顺序重新摆放在另一根柱子上。
//并且规定，在小圆盘上不能放大圆盘，在三根柱子之间一回只能移动一个圆盘，
//只能移动在最顶端的圆盘。


//算法思想：
//1.把A柱上的n-1个盘子移动到B柱上（借助C柱）
//2.把A柱的最后一个盘子移动到C柱
//3.把B柱的n-1个盘子移动到C柱（借助A柱）

int i = 1;//记录移动的步数

void move1(char A, char B)//移动一个盘子
{
	
	cout <<"第"<<i++<< "步移动:" << A << "-->" << "至" << B << endl;

}
void moven(int n, char A, char B, char C) //A柱上的n个盘子 -------------> C柱
{
	if (n == 1) {
		move1(A, C);
	}
	else
	{
		moven(n - 1, A, C, B);//A柱上的n-1个盘子 -------------> B柱
		move1(A, C);//A柱上的最后一个盘子 -------------> C柱
		moven(n - 1, B, A, C);//B柱上的n-1个盘子 -------------> C柱
	}

}

int main()
{
	int m;

	cout << "请输入初始圆盘数量：" << endl;
	cin >> m;
	cout << "移动顺序为：" << endl;
	moven(m, 'A', 'B', 'C');
	cout <<"移动"<<m<<"片圆盘"<< "一共需要" << i-1 << "步操作完成移动" << endl;



	system("pause");
	return 0;


}
```

![6.7.1.jpg](https://b3logfile.com/file/2020/10/6.7.1-47bb7831.jpg)

#### 二维数组输出字符字母

```
#include <iostream>
using namespace std;



int main()
{
	int a[7][7] = {
		{1,1,1,1,1,1,1},
		{0,0,0,0,0,1,0},
		{0,0,0,0,1,0,0},
		{0,0,0,1,0,0,0},
		{0,0,1,0,0,0,0},
		{0,1,0,0,0,0,0},
		{1,1,1,1,1,1,1}
	};
	int b[7][7] = {
	{1,0,0,0,0,0,1},
	{0,1,0,0,0,1,0},
	{0,0,1,0,1,0,0},
	{0,0,0,1,0,0,0},
	{0,0,1,0,1,0,0},
	{0,1,0,0,0,1,0},
	{1,0,0,0,0,0,1}
	};

	for (int i = 0;i < 7;i++)//Z
	{
		for (int j = 0;j < 7;j++) 
		{
			if (a[i][j] == 1)
			{
				cout << "*";
			}
			else
			{
				cout << " ";
			}
		}
		cout << endl;
	}
	cout << endl;


	for (int i = 0;i < 7;i++)//Z
	{
		for (int j = 0;j < 7;j++)
		{
			if (a[i][j] == 1)
			{
				cout << "*";
			}
			else
			{
				cout << " ";
			}
		}
		cout << endl;
	}
	cout << endl;


	for (int i = 0;i < 7;i++)//X
	{
		for (int j = 0;j < 7;j++)
		{
			if (b[i][j] == 1)
			{
				cout << "*";
			}
			else
			{
				cout << " ";
			}
		}
		cout << endl;
	}

	system("pause");
	return 0;


}
```

![7.1.1.jpg](https://b3logfile.com/file/2020/10/7.1.1-1dbd09d1.jpg)

#### 判断字符串中有多少个整数

输入一个字符串，内有数字和非数字字符，判断字符串中有多少个整数，连续的数字算一个整数

```
#include<iostream>
#include<string>
#include<iomanip>
using namespace std;
//该函数将字符串中的连续数字存入整型数组a中，并返回a中整数的个数
int findInteger(char* p, int* a)
{
	int j, n = 0, i, k;
	char temp[100];//存放连续的数字，以便转换成整数
	for (i = 0;p[i] != '\0';i++)   //    '0'表示字符串结束符
	{
		j = 0;
		while (p[i] >= '0' && p[i] <= '9')//比较ASCII码，判断第i个字符是否是数字
		{
			temp[j] = p[i];//是的话，存入temp数组
			j++; 
			i++;
		}
		if (j != 0)//如果存在连续的数字
		{
			*a = atoi(temp);//atoi函数的功能是将字符串转换成正整数
			a++;
			n++;
			for (k = 0;k < j;k++)//将数组temp清零，以便存放下一个数字
				temp[k] = 0;
			i--;
		}
	}
	return n;
}
int main()
{
	int i, m, a[100];
	char line[100];
	cout << "请输入一个字符串:" << endl;
	cin >> line;
	m = findInteger(line, a);
	cout << "字符串中共有：" << m << "个整数" << endl;

	for (i = 0;i < m;i++) 
	{
		cout << a[i] << endl;
	}

	cout << endl;
	system("pause");
	return 0;
}
```

![8.9.1.jpg](https://b3logfile.com/file/2020/10/8.9.1-4ecda2a7.jpg)

