title: 如何实现www.XX原神大学.com
date: '2023-11-24 16:51:28'
updated: '2023-12-15 13:02:18'
tags: [待分类]
permalink: /articles/2023/11/24/1700815888101.html
---
![](https://z1.ax1x.com/2023/11/28/piBxmJU.jpg)

1. 注册域名   注册网站(.com的会贵 .top的便宜) [https://wanwang.aliyun.com/](https://wanwang.aliyun.com/)
   [![piBxuz4.png](https://z1.ax1x.com/2023/11/28/piBxuz4.png)](https://imgse.com/i/piBxuz4)
2. 域名实名认证
   [![piBxQy9.png](https://z1.ax1x.com/2023/11/28/piBxQy9.png)](https://imgse.com/i/piBxQy9)
3. 购买服务器  阿里云云服务器(腾讯云也可以，哪个便宜买哪个)
   [![piBxeiT.png](https://z1.ax1x.com/2023/11/28/piBxeiT.png)](https://imgse.com/i/piBxeiT)
4. linux宝塔界面安装   CSDN有完整教程(简单无脑)
   [![piBxnWF.png](https://z1.ax1x.com/2023/11/28/piBxnWF.png)](https://imgse.com/i/piBxnWF)
5. ICP域名备案申请  (下载阿里云APP有操作引导)
   [![piBxMQJ.jpg](https://z1.ax1x.com/2023/11/28/piBxMQJ.jpg)](https://imgse.com/i/piBxMQJ)
   [![piBxlLR.jpg](https://z1.ax1x.com/2023/11/28/piBxlLR.jpg)](https://imgse.com/i/piBxlLR)
6. ICP域名提交管局审核（会有专员打电话和你确认网站相关注册信息，一共大概7个工作日）[![piDJpQS.jpg](https://z1.ax1x.com/2023/11/29/piDJpQS.jpg)](https://imgse.com/i/piDJpQS)
7. ICP域名管局审核通过
   [![piDGxRf.jpg](https://z1.ax1x.com/2023/11/29/piDGxRf.jpg)](https://imgse.com/i/piDGxRf)
8. 设置域名解析  将域名解析记录值设置为自己云服务器的公网IP
   [![piBx3e1.png](https://z1.ax1x.com/2023/11/28/piBx3e1.png)](https://imgse.com/i/piBx3e1)
9. 打开宝塔界面   选择添加网站
   [![piDGzz8.png](https://z1.ax1x.com/2023/11/29/piDGzz8.png)](https://imgse.com/i/piDGzz8)
   [![piDGvJP.png](https://z1.ax1x.com/2023/11/29/piDGvJP.png)](https://imgse.com/i/piDGvJP)
10. 设置301重定向   重定向到自己学校官网
    [![piDGjit.png](https://z1.ax1x.com/2023/11/29/piDGjit.png)](https://imgse.com/i/piDGjit)
11. 等待十分钟  完成！

