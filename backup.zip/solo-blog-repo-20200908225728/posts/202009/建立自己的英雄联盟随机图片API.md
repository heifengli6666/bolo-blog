title: 建立自己的英雄联盟随机图片API
date: '2020-09-08 12:43:49'
updated: '2020-09-08 22:06:57'
tags: [自制随机图片API]
permalink: /articles/2020/09/08/1599540229522.html
---
![9ouy6.jpg](http://www.api.hanbaojian.top)

# 参考博客

[# 如何自制图片api接口](https://www.datealive.top/2020/05/imageapi/)
[# 简单的网站访问量计数器实现](https://blog.csdn.net/liu_jiachen/article/details/78358032)

# 为啥要建自己的API

~~闲的蛋疼~~ 自己的背景图和头图基本都是随机二次元动漫，因此想弄一个自己喜欢的随机背景API

# 基于Gitee建立自己图床

市面上的图床，访问速度快的要收费，免费又有很多局限，不如搭建自己的图床

1. 首先打开[Gitee官网](https://gitee.com/explore)
2. 登录账号/未注册的注册一个账号
3. 新建仓库
   ![12.jpg](https://b3logfile.com/file/2020/09/12-2ce49a49.jpg)

按如下配置

![13.jpg](https://b3logfile.com/file/2020/09/13-596f3838.jpg)

点击创建

![15.jpg](https://b3logfile.com/file/2020/09/15-dd2750e3.jpg)

选择服务Gitee Pages

![16.jpg](https://b3logfile.com/file/2020/09/16-15fe1d8b.jpg)

启动     等待一两分钟

![17.jpg](https://b3logfile.com/file/2020/09/17-f4e99cce.jpg)

这就得到你的网站地址

上传文件
![18.jpg](https://b3logfile.com/file/2020/09/18-1a2cb074.jpg)

![19.jpg](https://b3logfile.com/file/2020/09/19-0c856853.jpg)

此处上传一张图片为例，最多一小时内只能上传20个文件

![20.jpg](https://b3logfile.com/file/2020/09/20-d2db7376.jpg)

上传成功后

![21.jpg](https://b3logfile.com/file/2020/09/21-016403d8.jpg)

更新服务

之后访问你的网站地址/你上传的图片名称

![323.jpg](https://b3logfile.com/file/2020/09/323-d8ea4346.jpg)

至此图床搭建完毕

# php自制随机图片API

新建index.php文件

```
<?php
//存有链接的文件名，这里是存放图片链接的txt文件
$filename = "index.txt";
if(!file_exists($filename)){
die('文件不存在');
}

//从文本获取链接
$pics = [];
$fs = fopen($filename, "r");
while(!feof($fs)){
$line=trim(fgets($fs));
if($line!=''){
array_push($pics, $line);
}
}

//从数组随机获取链接
$pic = $pics[array_rand($pics)];

//返回指定格式
$type=$_GET['type'];
switch($type){

//JSON返回
case 'json':
header('Content-type:text/json');
die(json_encode(['pic'=>$pic]));

default:
die(header("Location: $pic"));
}
```

新建index.txt，里面存放你图片的链接

```
http://black_pineapple_6666.gitee.io/api/1.jpg
http://black_pineapple_6666.gitee.io/api/2.jpg
http://black_pineapple_6666.gitee.io/api/3.jpg
http://black_pineapple_6666.gitee.io/api/4.jpg
http://black_pineapple_6666.gitee.io/api/5.jpg
http://black_pineapple_6666.gitee.io/api/6.jpg
http://black_pineapple_6666.gitee.io/api/7.jpg
http://black_pineapple_6666.gitee.io/api/8.jpg
http://black_pineapple_6666.gitee.io/api/9.jpg
http://black_pineapple_6666.gitee.io/api/10.jpg
http://black_pineapple_6666.gitee.io/api/11.jpg
http://black_pineapple_6666.gitee.io/api/12.jpg
http://black_pineapple_6666.gitee.io/api/13.jpg
http://black_pineapple_6666.gitee.io/api/14.jpg
http://black_pineapple_6666.gitee.io/api/15.jpg
http://black_pineapple_6666.gitee.io/api/16.jpg
http://black_pineapple_6666.gitee.io/api/17.jpg
http://black_pineapple_6666.gitee.io/api/18.jpg
http://black_pineapple_6666.gitee.io/api/19.jpg
http://black_pineapple_6666.gitee.io/api/20.jpg
http://black_pineapple_6666.gitee.io/api/21.jpg
http://black_pineapple_6666.gitee.io/api/22.jpg
http://black_pineapple_6666.gitee.io/api/23.jpg
http://black_pineapple_6666.gitee.io/api/24.jpg
http://black_pineapple_6666.gitee.io/api/25.jpg
http://black_pineapple_6666.gitee.io/api/26.jpg
http://black_pineapple_6666.gitee.io/api/27.jpg
http://black_pineapple_6666.gitee.io/api/28.jpg
http://black_pineapple_6666.gitee.io/api/29.jpg
http://black_pineapple_6666.gitee.io/api/30.jpg
http://black_pineapple_6666.gitee.io/api/31.jpg
http://black_pineapple_6666.gitee.io/api/32.jpg
http://black_pineapple_6666.gitee.io/api/33.jpg
http://black_pineapple_6666.gitee.io/api/34.jpg
http://black_pineapple_6666.gitee.io/api/35.jpg
http://black_pineapple_6666.gitee.io/api/36.jpg
http://black_pineapple_6666.gitee.io/api/37.jpg
http://black_pineapple_6666.gitee.io/api/38.jpg
http://black_pineapple_6666.gitee.io/api/39.jpg
http://black_pineapple_6666.gitee.io/api/40.jpg
http://black_pineapple_6666.gitee.io/api/41.jpg
http://black_pineapple_6666.gitee.io/api/42.jpg
http://black_pineapple_6666.gitee.io/api/43.jpg
http://black_pineapple_6666.gitee.io/api/44.jpg
http://black_pineapple_6666.gitee.io/api/45.jpg
http://black_pineapple_6666.gitee.io/api/46.jpg
http://black_pineapple_6666.gitee.io/api/47.jpg
http://black_pineapple_6666.gitee.io/api/48.jpg
http://black_pineapple_6666.gitee.io/api/49.jpg
http://black_pineapple_6666.gitee.io/api/50.jpg
http://black_pineapple_6666.gitee.io/api/51.jpg
http://black_pineapple_6666.gitee.io/api/52.jpg
http://black_pineapple_6666.gitee.io/api/53.jpg
http://black_pineapple_6666.gitee.io/api/54.jpg
http://black_pineapple_6666.gitee.io/api/55.jpg
http://black_pineapple_6666.gitee.io/api/56.jpg
http://black_pineapple_6666.gitee.io/api/57.jpg
http://black_pineapple_6666.gitee.io/api/58.jpg
http://black_pineapple_6666.gitee.io/api/59.jpg
http://black_pineapple_6666.gitee.io/api/60.jpg
```

这时的你可能要问了，这么多个链接一个一个输入吗？可以，但是没有必要

打开已经落灰的VC++
![C6ZJU3Z3C8VVD1HSG.png](https://b3logfile.com/file/2020/09/C6ZJU3Z3C8VVD1HSG-0f727704.png)

```
#include <stdio.h>
#include<math.h>
int a;
int main()
{
	for(a=1;a<=357;a=a+1)
	printf("http://black_pineapple_6666.gitee.io/api/%d.jpg\n",a);
	return 0;
}
```

当然你也可以用很多在线编程的软件和其他语言，顺序输出就是了

# 布置站点

接下来给你的API弄个二级域名啥的，比如我的www.api.hanbaojian.top

布置你的文件,将index.php和index.txt放置在同一级目录下

至此全部工作完成

访问站点http://www.api.hanbaojian.top

![e213.png](https://b3logfile.com/file/2020/09/e213-549dbf06.png)

# 增加API调用次数统计

在index.php中 <?php 后增加如下计数器代码

```
/////////////////////////计数器
        $max_len = 9;
        $CounterFile = "counter.txt";
        if(!file_exists($CounterFile)){        //如果计数器文件不存在
            $counter = 0;                  
            $cf = fopen($CounterFile,"w");  //打开文件
            fputs($cf,'0');                    //初始化计数器
            fclose($cf);                   //关闭文件
        }
        else{                                       //取回当前计数器的值
            $cf = fopen($CounterFile,"r");
            $counter = trim(fgets($cf,$max_len));
            fclose($cf);
        }
        $counter++;                                    //计数器加一
        $cf = fopen($CounterFile,"w");              //写入新的数据
        fputs($cf,$counter);
        fclose($cf);
```

在index.php同级目录下新建counter.txt文件，初始值设为为0

每当index.php被访问一次，计数值加一

访问你的网站/counter.txt即可得到访问量

例如http://www.api.hanbaojian.top/counter.txt

