title: C++实现简单通讯录功能
date: '2020-09-24 22:49:15'
updated: '2020-09-25 23:29:18'
tags: [C++]
permalink: /articles/2020/09/24/1600958955393.html
---
![](https://b3logfile.com/bing/20200907.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

<center><iframe scrolling="no" src="https://datealive.top/IP-master/index.php" frameborder="0"
width="356" height="240" allowtransparency="true"></iframe></center>

## 系统需求

通讯录是一个可以记录亲人、好友信息的工具。

本教程主要利用C++来实现一个通讯录管理系统

系统中需要实现的功能如下：

* 添加联系人：向通讯录中添加新人，信息包括（姓名、性别、年龄、联系电话、家庭住址）最多记录1000人
* 显示联系人：显示通讯录中所有联系人信息
* 删除联系人：按照姓名进行删除指定联系人
* 查找联系人：按照姓名查看指定联系人信息
* 修改联系人：按照姓名重新修改指定联系人
* 清空联系人：清空通讯录中所有信息
* 退出通讯录：退出当前使用的通讯录

## 代码实现

```
#include <iostream>
using namespace std;
#define MAX 1000
//联系人结构体
struct Person {
	//姓名
	string m_Name;
	//性别  1-男  2-女
	int m_Sex;
	//年龄
	int m_Age;
	//电话
	string m_Phone;
	//住址
	string m_Addr;
};
//通讯录结构体
struct Addressbooks {
	//通讯录中保存的联系人数组
	struct Person personArray[MAX];
	//通讯录中当前记录联系人个数
	int m_Size;
};


//添加联系人
void addPerson(Addressbooks * abs) {
	//判断通讯录是否已满，如果满了就不再添加
	if (abs->m_Size == MAX) {
		cout << "通讯录已经满了，无法添加！" << endl;
		return;
	}
	else {

		//添加联系人

		//姓名
		string name;
		cout << "请输入姓名：" << endl;
		cin >> name;
		abs->personArray[abs->m_Size].m_Name = name;
		//性别
		cout << "请输入性别：" << endl;
		cout << "1---- 男" << endl;
		cout << "2---- 女" << endl;
		int sex = 0;
		while (true) {
			cin >> sex;
			if (sex == 1 || sex == 2) {
				abs->personArray[abs->m_Size].m_Sex = sex;
				break;
			}
			
			cout << "输入有误，请重新输入" << endl;

			

		}
		
		//年龄
		cout << "请输入年龄：" << endl;
		int age = 0;
		while (true) {
			cin >> age;
			if (age < 150|| age >10) {
				abs->personArray[abs->m_Size].m_Age = age;
				break;
			}
			cout << "输入有误，请重新输入" << endl;
			
		}

		//电话
		cout << "请输入联系电话：" << endl;
		string phone;
		cin >> phone;
		abs->personArray[abs->m_Size].m_Phone = phone;

		//住址
		cout << "请输入家庭住址：" << endl;
		string address;
		cin >> address;
		abs->personArray[abs->m_Size].m_Addr = address;


		abs->m_Size++;
		cout << "添加成功！" << endl;
		
		system("pause");//按任意键继续
		system("cls");//清屏

	}
}
//显示所有联系人
void showPerson(Addressbooks* abs) {
	if (abs->m_Size == 0) {
		cout << "当前记录为空" << endl;
	}
	else {
		for (int i = 0;i < abs->m_Size;i++) {
			cout << "姓名：" << abs->personArray[i].m_Name<<" ";
			cout << "性别：" << (abs->personArray[i].m_Sex == 1 ? "男":"女") << " ";
			cout << "年龄：" << abs->personArray[i].m_Age << " ";
			cout << "电话：" << abs->personArray[i].m_Phone << " ";
			cout << "住址：" << abs->personArray[i].m_Addr
				 << endl;
		}
	}
	system("pause");
	system("cls");
}
//检测联系人是否存在，如果存在，返回联系人所在数组在的具体位置，不存在返回-1
int isExist(Addressbooks* abs, string name) {
	for (int i = 0;i < abs->m_Size;i++) {
		if (abs->personArray[i].m_Name == name)
		{
			return i;//找到了，返回这个人在数组的下标
		}

	}
	return -1;//找不到
}
//删除指定联系人
void deletePerson(Addressbooks* abs) {
	cout << "请输入您要删除的联系人：" << endl;
	string name;
	cin >> name;

	int ret = isExist(abs, name);
	if (ret != -1) {
		//找到此人，进行删除
		for (int i = ret;i < abs->m_Size;i++) {
			abs->personArray[i] = abs->personArray[i + 1];
		}
		abs->m_Size--;
		cout << "删除成功！" << endl;
	}
	else {
		//查无此人
		cout << "查无此人！" << endl;
	}
	system("pause");
	system("cls");
}
//查找指定联系人信息
void findPerson(Addressbooks* abs) {
	cout << "请输入您要查找的联系人：" << endl;
	string name;
	cin >> name;

	int ret = isExist(abs, name);
	if (ret != -1) {
		cout << "姓名：" << abs->personArray[ret].m_Name << "\t";
		cout << "性别：" << abs->personArray[ret].m_Sex << "\t";
		cout << "年龄：" << abs->personArray[ret].m_Age << "\t";
		cout << "电话：" << abs->personArray[ret].m_Phone << "\t";
		cout << "住址：" << abs->personArray[ret].m_Addr << "\t"
		<< endl;

	}
	else {
		cout << "查无此人" << endl;
	}
	system("pause");
	system("cls");
}
//修改指定联系人的信息
void modifyPerson(Addressbooks* abs) {

	cout << "请输入您要修改的联系人：" << endl;
	string name;
	cin >> name;
	int ret = isExist(abs, name);

	if (ret != -1) {

		string name;
		cout << "请输入姓名：" << endl;
		cin >> name;
		abs->personArray[ret].m_Name = name;

		cout << "请输入性别：" << endl;
		cout << "1---男" << endl;
		cout << "2---女" << endl;
		int sex = 0;
		cin >> sex;
		while (true) {
			if (sex == 1 || sex == 2) {
			abs->personArray[ret].m_Sex = sex;
		 	break;
			}
		cout << "输入有误，请重新输入" << endl;
	    }
		
		cout << "请输入年龄：" << endl;
		int age=0;
		cin >> age;
		abs->personArray[ret].m_Age = age;


		cout << "请输入联系电话：" << endl;
		string phone;
		cin >> phone;
		abs->personArray[ret].m_Phone = phone;


		cout << "请输入家庭住址：" << endl;
		string address;
		cin >> address;
		abs->personArray[ret].m_Addr = address;


		cout << "修改成功！" << endl;

	}
	else {
		cout << "查无此人" << endl;
	}
	system("pause");
	system("cls");

}
//清空联系人
void cleanPerson(Addressbooks*abs) {
	cout << "您是否确定要删除所有联系人？" << endl;
	cout << "输入 Y 为确定   " ;
	cout << "输入其他键则返回主菜单" << endl;
	char a ;
	cin >> a;
	if (a == 'Y') {
		int ret = abs->m_Size;
		if (ret == 0) {
			cout << "本来就是空的！" << endl;
			system("pause");
			system("cls");
			return;

		}
		else {
			abs->m_Size = 0;//逻辑清空
			cout << "清除成功！" << endl;
			system("pause");
			system("cls");
		}
		
	}
	else {
		system("pause");
		system("cls");
		return;
	}

}
//菜单显示
void showMenu() {
	cout << "*****************************" << endl;
	cout << "*****	1.添加联系人	*****" << endl;
	cout << "*****	2.显示联系人	*****" << endl;
	cout << "*****	3.删除联系人	*****" << endl;
	cout << "*****	4.查找联系人	*****" << endl;
	cout << "*****	5.修改联系人	*****" << endl;
	cout << "*****	6.清空联系人	*****" << endl;
	cout << "*****	0.退出该系统	*****" << endl;
	cout << "*****************************" << endl;
}
int main()
{

	//创建通讯录结构体变量
	Addressbooks abs;
	//初始化通讯录中当前人员个数
	abs.m_Size = 0;


	int select = 0;//创建用户选择输入的变量
	while (true) {//循环使用
		//菜单调用
		showMenu();
		//用户选择想要功能
		cin >> select;

		switch (select) {
		case 1://添加联系人
			addPerson(&abs);
			break;
		case 2:// 显示联系人
			showPerson(&abs);
			break;
		case 3: // 删除联系人
			deletePerson(&abs);
			break;
		case 4://查找联系人
			findPerson(&abs);
			break;
		case 5://修改联系人
			modifyPerson(&abs);
			break;
		case 6:// 清空联系人
			cleanPerson(&abs);
			break;
		case 0:// 退出通讯录
			cout << "欢迎下次使用,再见!" << endl;
			system("pause");
			return 0;
			break;
		default:
			break;
		}
	}


	system("pause");
	return 0;


}
```

## 项目演示

![11.jpg](https://b3logfile.com/file/2020/09/11-69c86eaf.jpg)
![12.jpg](https://b3logfile.com/file/2020/09/12-c89aa5a4.jpg)
![13.jpg](https://b3logfile.com/file/2020/09/13-9e92154c.jpg)
![14.jpg](https://b3logfile.com/file/2020/09/14-4c2743ef.jpg)
![15.jpg](https://b3logfile.com/file/2020/09/15-fc8a3daf.jpg)
![16.jpg](https://b3logfile.com/file/2020/09/16-920db1e0.jpg)
![17.jpg](https://b3logfile.com/file/2020/09/17-067a71b3.jpg)
![18.jpg](https://b3logfile.com/file/2020/09/18-b4aa6564.jpg)
![20.jpg](https://b3logfile.com/file/2020/09/20-ef84272c.jpg)

