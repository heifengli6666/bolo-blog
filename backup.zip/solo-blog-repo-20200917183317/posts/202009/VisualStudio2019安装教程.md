title: Visual Studio 2019安装教程
date: '2020-09-17 15:12:12'
updated: '2020-09-17 15:14:33'
tags: [C++]
permalink: /articles/2020/09/17/1600326732106.html
---
![](https://b3logfile.com/bing/20181107.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 打开官网

[https://visualstudio.microsoft.com/zh-hans/](https://visualstudio.microsoft.com/zh-hans/)
![11.jpg](https://b3logfile.com/file/2020/09/11-7709cf98.jpg)

开始下载安装

# 工作负载选择

![12.jpg](https://b3logfile.com/file/2020/09/12-bd50038e.jpg)

开始下载并重启

# 密钥激活

![13.jpg](https://b3logfile.com/file/2020/09/13-0e779655.jpg)

```
NYWVH-HT4XC-R2WYW-9Y3CM-X4V3Y
```

# Hello world

![15.jpg](https://b3logfile.com/file/2020/09/15-2d9b624d.jpg)

![16.jpg](https://b3logfile.com/file/2020/09/16-ad42f87e.jpg)

![20.jpg](https://b3logfile.com/file/2020/09/20-1bf0ea04.jpg)

![222.jpg](https://b3logfile.com/file/2020/09/222-4b955344.jpg)

```
#include <iostream>
using namespace std;

int main()
{
	cout << "Hello world" << endl;
	system("pause");

	return 0;

}
```

![223.jpg](https://b3logfile.com/file/2020/09/223-c8b236d4.jpg)
![224.jpg](https://b3logfile.com/file/2020/09/224-a79fcce4.jpg)

