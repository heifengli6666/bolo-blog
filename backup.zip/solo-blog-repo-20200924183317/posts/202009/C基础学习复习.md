title: C++基础学习/复习
date: '2020-09-20 08:11:40'
updated: '2020-09-24 10:17:02'
tags: [C++]
permalink: /articles/2020/09/20/1600560700833.html
---
![111.jpg](https://b3logfile.com/file/2020/09/111-89def047.jpg)

# 多行格式if语句

### 三只小猪称体重

有三只小猪ABC，请分别输入三只小猪的体重，并且判断哪只小猪最重？

![三只小猪.jpg](https://b3logfile.com/file/2020/09/三只小猪-956d7cc1.jpg)

```
#include <iostream>
using namespace std;

int main()
{
	int p1 = 0;
	int p2 = 0;
	int p3 = 0;
	cout << "请输入第一只小猪的体重：" << endl;
	cin >> p1;
	cout << "请输入第二只小猪的体重：" << endl;
	cin >> p2;
	cout << "请输入第三只小猪的体重：" << endl;
	cin >> p3;
	cout << "第一只小猪的体重为：" << p1 << endl;
	cout << "第二只小猪的体重为：" << p2 << endl;
	cout << "第三只小猪的体重为：" << p3 << endl;
	

	if (p1 >= p2 && p1 >= p3) {
		cout << "第一只小猪最重"<< endl;
	}
	else if (p2 >= p1 && p2 >= p3) {
		cout << "第二只小猪最重" << endl;
	}
	else {
		cout << "第三只小猪最重" << endl;
	}


	system("pause");
	return 0;


}
```

---

# 三目运算符

**语法：**`表达式1 ? 表达式2 ：表达式3`

**解释：**

如果表达式1的值为真，执行表达式2，并返回表达式2的结果；

如果表达式1的值为假，执行表达式3，并返回表达式3的结果。

### 两只小猪比体重

```
#include <iostream>
using namespace std;

int main()
{
	int p1 = 0;
	int p2 = 0;
	int p3 = 0;
	cout << "请输入第一只小猪的体重：" << endl;
	cin >> p1;
	cout << "请输入第二只小猪的体重：" << endl;
	cin >> p2;
	cout << "第一只小猪的体重为：" << p1 << endl;
	cout << "第二只小猪的体重为：" << p2 << endl;
	
	p3 = (p1 > p2 ? p1 : p2);

	cout << "最重小猪的体重为：" << p3 << endl;
	
	//在C++中三目运算符返回的是变量，可以继续赋值
	(p1 > p2 ? p1 : p2) = 520;
	cout << "将最重的小猪的体重置为520" << endl;
	cout << "第一只小猪的体重为：" << p1 << endl;
	cout << "第二只小猪的体重为：" << p2 << endl;

	system("pause");
	return 0;


}
```

---

# while循环语句

### 猜数字

while循环练习案例：猜数字
案例描述：系统随机生成一个1到100之间的数字，玩家进行猜测，如果猜错，提示玩家数字过大或过小，如果猜对恭喜玩家胜利，并且退出游戏。

```
#include <iostream>
using namespace std;
#include<ctime>
int main()
{
	srand((unsigned int)time(NULL));//根据系统时间提供种子
	int x = rand()%100+1;//系统生成随机数
	int num = 0;
	cout << "请猜测" << endl;
	cin >> num;
	while (num != x) {
		if(num>x){
			cout << "大了，请重猜" << endl;
		}
		else
		{
			cout << "小了，请重猜" << endl;
		}
		cin >> num;

	}
	cout << "恭喜你猜对了" << endl;

	system("pause");
	return 0;


}
```

### 水仙花数

练习案例：水仙花数
案例描述：水仙花数是指一个 3 位数，它的每个位上的数字的 3次幂之和等于它本身

例如：1^3 + 5^3+ 3^3 = 153

请利用do...while语句，求出所有4位数中的水仙花数

```
#include <iostream>
using namespace std;

int main()
{
	int num = 1000;
	int a = 0;//千位
	int b = 0;//百位
	int c = 0;//十位
	int d = 0;//个位
	do {
		a = num / 1000 ;
		b =(num - 1000 * a) / 100 ;
		c =(num - (1000 * a + 100 * b)) / 10;
		d = num % 10;
		if (a*a*a*a + b*b*b*b + c*c*c*c + d*d*d*d == num) {
			cout << num << endl;
			num++;
		}
		else {
			num++;
		}
	} while (num<10000);
	system("pause");
	return 0;


}
```

输出结果：

```
1634
8208
9474
请按任意键继续. . .
```

---

# for循环语句

### 敲桌子

练习案例：敲桌子

案例描述：从1开始数到数字100， 如果数字个位含有7，或者数字十位含有7，或者该数字是7的倍数，我们打印敲桌子，其余数字直接打印输出。

![timg.gif](https://b3logfile.com/file/2020/09/timg-9c95363a.gif)

```
#include <iostream>
using namespace std;

int main()
{
	int count = 0;
	for (int i = 1;i < 101;i++) {
		int x = 0;
		x = i / 10 ;
		
		if (i % 7 == 0 || i / 10 == 7 || (i-x*10) - 7 == 0) {
			cout << "敲桌子" << endl;
			count++;
		}
		else {
			cout << i << endl;
		}
		
	}
	cout << "共有" << count << endl;
	system("pause");
	return 0;


}
```

---

# 嵌套循环

### 乘法口诀表

练习案例：乘法口诀表

案例描述：利用嵌套循环，实现九九乘法表
![0006018857256120b.jpg](https://b3logfile.com/file/2020/09/0006018857256120b-0dd52697.jpg)

```
#include <iostream>
using namespace std;

int main()
{
	for (int i = 1,x=1;i < 10;i++){//行数
		
		for (int j = 1;j < x+1;j++) {//列数
			cout << j << "X" << x << "=" << x * j <<"   ";
		}
		cout << endl;
		x++;
	}
	system("pause");
	return 0;


}
```

---

# 一维数组

### 五只小猪称体重

在一个数组中记录了五只小猪的体重，如：int arr[5] = {300,350,200,400,250};

找出并打印最重的小猪体重。
解法一：

```
#include <iostream>
using namespace std;
//笨比方法
int main()
{
	int arr[5] = {300,350,200,400,250};
	if      (arr[0] >= arr[1] && arr[0] >= arr[2] && arr[0] >= arr[3] && arr[0] >= arr[4]) {
		cout << "第1只小猪最重，体重为：" << arr[0] << endl;
	}
	else if (arr[1] >= arr[0] && arr[1] >= arr[2] && arr[1] >= arr[3] && arr[1] >= arr[4]) {
		cout << "第2只小猪最重，体重为：" << arr[1] << endl;
	}
	else if (arr[2] >= arr[0] && arr[2] >= arr[1] && arr[2] >= arr[3] && arr[2] >= arr[4]) {
		cout << "第3只小猪最重，体重为：" << arr[2] << endl;
	}
	else if (arr[3] >= arr[0] && arr[3] >= arr[1] && arr[3] >= arr[2] && arr[3] >= arr[4]) {
		cout << "第4只小猪最重，体重为：" << arr[3] << endl;
	}
	else {
		cout << "第5只小猪最重，体重为：" << arr[4] << endl;
	}
	system("pause");
	return 0;


}
```

解法二：

```
#include <iostream>
using namespace std;
int main()
{
	int arr[5] = {300,350,200,400,250};
	int x = 0;
	int y = 1;
	int z = 0;
	for (; x<5 && y<5;) {
		if (arr[x] >= arr[y]) {
			z = x;
			y++;
		}
		else  {
			z = y;
			x++;
		}	
	}
	cout << "第" << z + 1 << "只小猪最重,体重为：" << arr[z] << endl;
	system("pause");
	return 0;


}
```

### 数组元素逆置

案例描述：请声明一个5个元素的数组，并且将元素逆置.

(如原数组元素为：1,3,2,5,4;逆置后输出结果为:4,5,2,3,1);
解法一：

```
#include <iostream>
using namespace std;

int main()
{
	int arr[5] = { 1,3,2,5,4 };
	int arr1[5]= { 0,0,0,0,0 };
	cout << "原顺序为" ;
	for (int i = 0;i < 5;i++) {
		cout << arr[i];
	}
	for (int j = 0;j < 5;j++) {

		arr1[4 - j]=arr[j];
	}
	cout << endl << "逆置顺序为：";
	for (int k = 0;k < 5;k++) {
		cout <<  arr1[k];
	}


	cout << endl;
	system("pause");
	return 0;


}
```

解法二：

```
#include <iostream>
using namespace std;

int main()
{
	int arr[5] = { 1,3,2,5,4 };
	cout << "原顺序为";
	for (int i = 0;i < 5;i++) {
		cout << arr[i];
	}
	//2、实现逆置
	//2.1记录起始下标位置
	//2.2记录结束下标位置
	//2.3起始下标与结束下标的元素互换
	//2.4起始位置++  结束位置--
	//2.5循环执行2.1操作，直到起始位置 >= 结束位置
	int start = 0;//起始下标
	int end = sizeof(arr)/sizeof(arr[0])-1;//末尾下标
	while (start < end) {
		int temp = arr[start];
		arr[start] = arr[end];
		arr[end] = temp;
		start++;
		end--;
	}
	cout << endl << "逆置顺序为：";
	for (int k = 0;k < 5;k++) {
		cout << arr[k];
	}
	system("pause");
	return 0;

}
```

### 冒泡排序

```
#include <iostream>
using namespace std;

int main()
{
	int arr[]={ 4, 2, 8, 0, 5, 7, 1, 3, 9 };
	int end = sizeof(arr) / sizeof(arr[0]) - 1;
	cout << endl << "初始顺序为：";
	for (int k = 0;k < end + 1;k++) {
	cout << arr[k];
	}
	cout << endl;
	
	for (int j = 0;j < end;j++) {

		for (int i = 0;i < end-j;i++) {
		 int p = 0;
			if (arr[i] > arr[i + 1]) {
			p = arr[i + 1];
			arr[i + 1] = arr[i];
			arr[i] = p;

			}
		}
	}
	cout << endl << "冒泡顺序为：";
	for (int k = 0;k <end+1;k++) {
		cout << arr[k];
	}
	cout << endl;
	system("pause");
	return 0;


}
```

---

# 二维数组

### 二维数组的定义

```
#include <iostream>
using namespace std;

int main()
{
	//` 1.数据类型  数组名[ 行数 ][ 列数 ]; `
	int arr[2][3];
	arr[0][0] = 1;
	arr[0][1] = 2;
	arr[0][2] = 3;
	arr[1][0] = 4;
	arr[1][1] = 5;
	arr[1][2] = 6;

	for (int i = 0;i < 2;i++) {
		for (int j = 0;j < 3;j++) {
			cout << arr[i][j] << " ";
		}
		cout << endl;
	}
	cout << "------------------------------" << endl;
	//`2.数据类型  数组名[ 行数 ][ 列数 ] = { {数据1，数据2 } ，{数据3，数据4 } };`

	int arr2[2][3] = {
		{1,2,3},
		{4,5,6}
	};
	for (int i = 0;i < 2;i++) {
		for (int j = 0;j < 3;j++) {
			cout << arr2[i][j] << " ";
		}
		cout << endl;
	}

	cout << "------------------------------" << endl;
	//3.`数据类型  数组名[ 行数 ][ 列数 ] = { 数据1，数据2，数据3，数据4};`

	int arr3[2][3] = {1,2,3,4,5,6};
	for (int i = 0;i < 2;i++) {
		for (int j = 0;j < 3;j++) {
			cout << arr3[i][j] << " ";
		}
		cout << endl;
	}

	cout << "------------------------------" << endl;
	//4. 数据类型  数组名[  ][ 列数 ] = { 数据1，数据2，数据3，数据4};`

	int arr4[][3] = { 1,2,3,4,5,6 };
	for (int i = 0;i < 2;i++) {
		for (int j = 0;j < 3;j++) {
			cout << arr4[i][j] << " ";
		}
		cout << endl;
	}






	system("pause");
	return 0;


}
```

### 计算总成绩

考试成绩统计：**

案例描述：有三名同学（张三，李四，王五），在一次考试中的成绩分别如下表，**请分别输出三名同学的总成绩**

|      | 语文 | 数学 | 英语 |
| ---- | ---- | ---- | ---- |
| 张三 | 100  | 100  | 100  |
| 李四 | 90   | 50   | 100  |
| 王五 | 60   | 70   | 80   |

```
#include <iostream>
using namespace std;

int main()
{
	int arr[3][3] = {
		{100,100,100},
		{90,50,100},
		{60,70,80}
	};
	/*cout << "张三的总成绩为：" << arr[0][0] + arr[0][1] + arr[0][2] << endl;
	cout << "李四的总成绩为：" << arr[1][0] + arr[1][1] + arr[1][2] << endl;
	cout << "王五的总成绩为：" << arr[2][0] + arr[2][1] + arr[2][2] << endl;*/
	string names[3] = { "张三","李四","王五" };

	for (int i = 0;i < 3;  i++) {
		int sum = 0;
		for (int j = 0;j < 3;j++) {
			sum += arr[i][j];
		}
		cout << names[i] << "的总成绩为：" <<sum<< endl;
	}

	system("pause");
	return 0;


}
```

# 结构体

### 案例一

案例描述：

学校正在做毕设项目，每名老师带领5个学生，总共有3名老师，需求如下

设计学生和老师的结构体，其中在老师的结构体中，有老师姓名和一个存放5名学生的数组作为成员

学生的成员有姓名、考试分数，创建数组存放3名老师，通过函数给每个老师及所带的学生赋值

最终打印出老师数据以及老师所带的学生数据。

```
#include <iostream>
using namespace std;
#include <ctime>
//学校正在做毕设项目，每名老师带领5个学生，总共有3名老师，需求如下

//设计学生和老师的结构体，其中在老师的结构体中，有老师姓名和一个存放5名学生的数组作为成员

//学生的成员有姓名、考试分数，创建数组存放3名老师，通过函数给每个老师及所带的学生赋值

//最终打印出老师数据以及老师所带的学生数据。

struct Student {//学生的成员有姓名、考试分数
	string sName;//学生姓名
	int score;//学生分数
};


struct Teacher {//在老师的结构体中，有老师姓名和一个存放5名学生的数组作为成员
	string tName;//老师姓名
	struct Student sArray[5];//所带学生数组

};
//给老师学生赋值的函数
void allocateSpace(struct Teacher tArray[],int len) {
	string nameSeed = "ABCDE";
	for (int i = 0;i < len;i++) {
		tArray[i].tName = "Teacher_";
		tArray[i].tName += nameSeed[i];

		//通过循环给每名老师所带的学生赋值
		for (int j = 0;j < 5;j++) {
			tArray[i].sArray[j].sName = "Student_";
			tArray[i].sArray[j].sName += nameSeed[j];

			tArray[i].sArray[j].score = rand()%61+40;
		}
	}
}
void printInfo(struct Teacher tArray[],int len) {
	for (int i = 0;i < len;i++) {
		cout << "老师姓名:" << tArray[i].tName << endl;
		for (int j = 0;j < 5;j++) {
			cout << "学生姓名：" << tArray[i].sArray[j].sName
				 << "学生分数：" << tArray[i].sArray[j].score
				 << endl;
		}
	}
}
int main()
{
	//随机数种子
	srand((unsigned int)time(NULL));
	//创建3名老师的数组
	struct Teacher tArray[3];

	//通过函数给3名老师的信息赋值，并给老师带的学生信息赋值
	int len = 3;
	allocateSpace(tArray, len);

	//打印所以老师所带的学生信息、
	printInfo(tArray,len);
	system("pause");
	return 0;


}
```

代码结果
![333.jpg](https://b3logfile.com/file/2020/09/333-44aee4fc.jpg)

### 案例二

案例描述：

设计一个英雄的结构体，包括成员姓名，年龄，性别;创建结构体数组，数组中存放5名英雄。

通过冒泡排序的算法，将数组中的英雄按照年龄进行升序排序，最终打印排序后的结果。

五名英雄信息如下：

```
{"刘备",23,"男"},
        {"关羽",22,"男"},
        {"张飞",20,"男"},
        {"赵云",21,"男"},
        {"貂蝉",19,"女"},
```

```
#include <iostream>
using namespace std;
//设计一个英雄的结构体，包括成员姓名，年龄，性别;创建结构体数组，数组中存放5名英雄。
//通过冒泡排序的算法，将数组中的英雄按照年龄进行升序排序，最终打印排序后的结果。
//五名英雄信息如下：
//{ "刘备",23,"男" },
//{ "关羽",22,"男" },
//{ "张飞",20,"男" },
//{ "赵云",21,"男" },
//{ "貂蝉",19,"女" },

struct Hero {//定义英雄结构体
	string name;
	int age;
	string sex;
};

//打印排序结果
void printInfo(struct Hero Array[], int len) {
	//冒泡排序
	for (int i = 0;i < 4;i++) {	
		for (int j = 0;j < 4 - i;j++) {
			if (Array[j].age > Array[j + 1].age) {
				Hero temp = Array[j];
				Array[j] = Array[j + 1];
				Array[j + 1] = temp;
			}
		}
		
	}
	cout << "英雄按年龄升序排序为：" << endl;
	for (int i = 0;i < 5;i++) {
		cout << "姓名："<<Array[i].name
			 <<" 年龄："<<Array[i].age 
			 <<" 性别："<<Array[i].sex
			 << endl;
	}
		
}
int main()
{
	struct Hero Array[5] = {//给英雄结构体赋值
		{ "刘备",23,"男" },
		{ "关羽",22,"男" },
		{ "张飞",20,"男" },
		{ "赵云",21,"男" },
		{ "貂蝉",19,"女" }
	};


	int len = sizeof(Array) / sizeof(Array[0]);
	printInfo(Array, len);//打印排序结果


	system("pause");
	return 0;


}
```

![武切维奇.jpg](https://b3logfile.com/file/2020/09/武切维奇-1eeb359f.jpg)

---

学无止境，未完待续
------------------

此处学习资源来自B站黑马程序员

<div style="position: relative; padding: 30% 45%;">
<iframe style="position: absolute; width: 100%; height: 100%; left: 0; top: 0;" src="//player.bilibili.com/player.html?bvid=BV1et411b73Z&as_wide=1&high_quality=1&danmaku=1" scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true"></iframe>
</div>

