title: 博客正式绑定域名www.boke.hanbaojian.top
date: '2020-09-05 22:13:01'
updated: '2020-09-07 23:25:43'
tags: [前端皮毛]
permalink: /articles/2020/09/05/1599315181886.html
---
![22.jpg](https://b3logfile.com/file/2020/09/22-dbd6778a.jpg)



唉，折腾了两天终于给这个博客绑上的域名

因为直接把这个项目复制到tomcat的ROOT文件夹下，每次访问这个博客都是

服务器ip：8080

就很low
翻了几个教程
有说用301重定向的
确实实现了访问域名，然后加载出博客
但是博客的上方依然是服务器ip：8080
![111111.jpg](https://b3logfile.com/file/2020/09/111111-7f81c503.jpg)

然后又有说直接修改tomcat的配置文件
把默认的8080改成80
结果直接不能访问了，不知道哪里出了问题

翻来覆去终于找到了一篇16年的CSDN[教程](https://blog.csdn.net/lsm135/article/details/51879453?utm_medium=distribute.pc_relevant.none-task-blog-BlogCommendFromMachineLearnPai2-2.nonecase&depth_1-utm_source=distribute.pc_relevant.none-task-blog-BlogCommendFromMachineLearnPai2-2.nonecase)
修改了nginx的配置文件

```
<!--修改nginx.conf文件 -->
server {
        listen       80;
        server_name  www.xxx.cn;

        server_name_in_redirect off;
        proxy_set_header Host $host:$server_port;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header REMOTE-HOST $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;

    location / {
         proxy_pass http://***********:8080/;
        }
    }
<!--修改nginx.conf文件 -->
```

nginx永远的神！

===================分割线2020/9/7/22:35==================

## 点击某个项目后域名变为IP？

是否使用了 Nginx ？请检查你的 location 字段设置：

<pre class="prettyprint linenums prettyprinted"><ol class="linenums"><li class="L0"><p><code><span class="pln">location </span><span class="pun">/</span><span class="pln"> </span><span class="pun">{</span></code></p></li><li class="L1"><p><code><span class="pln">        proxy_pass http</span><span class="pun">:</span><span class="com">//127.0.0.1:800/;</span></code></p></li><li class="L2"><p><code><span class="pln">        proxy_set_header HOST $host</span><span class="pun">;</span></code></p></li><li class="L3"><p><code><span class="pln">        proxy_set_header X</span><span class="pun">-</span><span class="typ">Real</span><span class="pun">-</span><span class="pln">IP $remote_addr</span><span class="pun">;</span></code></p></li><li class="L4"><p><code><span class="pln">        proxy_set_header X</span><span class="pun">-</span><span class="typ">Forwarded</span><span class="pun">-</span><span class="typ">For</span><span class="pln"> $proxy_add_x_forwarded_for</span><span class="pun">;</span></code></p></li><li class="L5"><p><code><span class="pln">        proxy_set_header </span><span class="typ">Upgrade</span><span class="pln"> $http_upgrade</span><span class="pun">;</span></code></p></li><li class="L6"><p><code><span class="pln">        proxy_set_header </span><span class="typ">Connection</span><span class="pln"> </span><span class="str">&#34;upgrade&#34;</span><span class="pun">;</span></code></p></li><li class="L7"><p><code><span class="pun">}</span></code></p></li></ol></pre>

看了文档重新更新

```
<!--修改nginx.conf文件 -->
server {
        listen       80;
        server_name  www.xxx.cn;
        server_name_in_redirect off;
        proxy_set_header Host $host:$server_port;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header REMOTE-HOST $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;

    location / {
proxy_pass http://***********:8080/;
proxy_set_header HOST $host;
proxy_set_header X-Real-IP $remote_addr;
proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
proxy_set_header Upgrade $http_upgrade;
proxy_set_header Connection "upgrade";

}
}

<!--修改nginx.conf文件 -->
```

