title: 上文分享了音乐播放器插件，再给大家安利一个音乐播放器lx-music
date: '2020-09-05 13:09:19'
updated: '2020-09-07 23:27:10'
tags: [安利]
permalink: /articles/2020/09/05/1599282559863.html
---
![113.jpg](https://b3logfile.com/file/2020/09/113-fd82539c.jpg)



### 奉上链接

github项目[链接](https://github.com/lyswhut/lx-music-desktop#readme),也可以网盘下载[地址](https://t-s.lanzous.com/b0bf2cfa) 密码：glqw

### 安利原因

1. 界面简洁，无广告
   ![12.jpg](https://b3logfile.com/file/2020/09/12-248de61a.jpg)
   作者承诺：
   ![16.jpg](https://b3logfile.com/file/2020/09/16-b5bbb7a2.jpg)
2. 歌曲丰富，基本都有，再也不用在各个软件到处换了
   ![14.jpg](https://b3logfile.com/file/2020/09/14-7ee6339f.jpg)
3. 无损音质
   ![15.jpg](https://b3logfile.com/file/2020/09/15-577f3daf.jpg)

### 更多功能等你挖掘

心动不如行动，快去试试吧

