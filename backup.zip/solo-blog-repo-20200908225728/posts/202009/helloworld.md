title: hello,world!
date: '2020-09-04 16:11:48'
updated: '2020-09-05 23:08:47'
tags: [hello-world]
permalink: /first
---
![](https://s1.ax1x.com/2020/09/05/wE62QS.jpg)

#### 说在前面

哈哈哈哈哈，请允许我先高兴一会儿，我的个人博客终于搭起来了！

## 正文开始

1. **为什么要搭建自己的个人博客？** 从我2020/7/30（考研复试上岸，咸鱼放纵了几个月，突然觉得自己不能再浪费青春了）开始接触前端知识，看了很多大佬炫酷吊炸天的博客界面和自己的专属域名，就萌生了自己也要搭一个的念头。
2. **为什么选择bolo搭建个人博客？**  ~~就这个搭成功了~~ ，bolo是个动态的开源博客模板，基本可以满足我的需求，至少不用像我一开始弄的[静态博客](http://www.bk.hanbaojian.top)一样，改一个字就要去修改源码，重传服务器，代码某个地方有bug，整个网页都崩了,还很难发现问题所在；最主要的是不能实现互动，就很low。发现这个弊端之后，我去[码云](https://gitee.com/explore)找了几个CMS框架，结果要么配置太复杂 ~~自己太菜答不起来~~  ；要么好不容易搭建起来了就一个空头框架，里面一些模板和内容还要收费；要么自己的自由度太低了，什么都不能改；最后用了[mblog](https://gitee.com/mtons/mblog)搭起来一个，但感觉不是自己想要的 ~~界面没有想象的花里胡哨~~，又回头开始琢磨改进静态网页；静态网页加上登录注册评论不就行了吗，于是我又试了一堆评论插件，最后用了[gittalk](https://github.com/gitalk/gitalk) ~~就这个成功了~~，这个插件的弊端在于游客无法评论，不是人人都有github的账号~~不是人人都秃头~~，而且一言不合就network error,还要去github刷新插件。
3. 于是乎，又想去找其他的评论插件，结果阴差阳错在某个博主找到了bolo的介绍（[小令童鞋](https://www.zeekling.cn/articles/2019/09/07/1587898561235.html)），( ´･ᴗ･` )ღ比心，抱着试一试的心态去看了一下，结果发现这个宝藏博客模板，可能这就是缘分吧！
4. **怎么搭起来的？小白也可以吗？** 可以，我感觉有手就行！[官方教程](https://doc.stackoverflow.wiki/web/#/7?page_id=46)，我简单说一下我怎么搭的吧 ，如果你还在和我之前一样还在寻找，你一定要试试！
   
   首先你得买个服务器，我这个用的是腾讯云的[标准型SA2](https://cloud.tencent.com/act/anniversary)（新用户三年￥288，挺香的，你也可以新人白嫖15天），进入管理界面后重置登录密码，建议新建一个记事本，记录常用的命令和账号密码。

![12.jpg](https://b3logfile.com/file/2020/09/12-269483cc.jpg)
然后去开放端口
![33.jpg](https://b3logfile.com/file/2020/09/33-5caae6b7.jpg)
打开常用的端口就行了，之后有需要再来配

![55.jpg](https://b3logfile.com/file/2020/09/55-bb268445.jpg)

**买了服务器，看不到，摸不着的，怎么用呢？**
我用的是PUTTY和XFTP（安装教程去CSDN找，无脑下一步就行），PUTTY是命令行操控服务器，XFTP可以直接操纵服务器的文件（大佬都直接用命令行）。这两个登录账号都是你的服务器的公网ip
进入PUTTY
![22.jpg](https://b3logfile.com/file/2020/09/22-6292dd39.jpg)

```
#进入PUTTY
login as：root
```

密码是你之前重置的那个，因为是暗文输入，自己看不见没关系的，输入完回车就行了。

![23.jpg](https://b3logfile.com/file/2020/09/23-b36ee537.jpg)

这个就是登录成功界面

![24.jpg](https://b3logfile.com/file/2020/09/24-acf04caa.jpg)

然后复制这段代码安装宝塔面板（小白适用，就是给你装环境变量）
![25.jpg](https://b3logfile.com/file/2020/09/25-989f1848.jpg)

```
#安装宝塔面板
yum install -y wget && wget -O install.sh http://download.bt.cn/install/install.sh && sh install.sh
```

复制代码，然后右键就行了，回车执行

中途它会问你个什么东西（没有当我没说），你输入y就行了，一两分钟就安装完成了
![222222222222.png](https://b3logfile.com/file/2020/09/222222222222-d22e3032.png)
这张是盗的图，反正你最后能看到一个网站（http://XXXXX:8888），用户名，密码。

复制这个网址到浏览器打开，输入账号密码
![123.jpg](https://b3logfile.com/file/2020/09/123-409575ac.jpg)
一开始让你选择配置，选择左边的带nginx的配置，然后安装（大概5分钟）
安装完成之后
单独找到TOMCAT，然后安装
![67.jpg](https://b3logfile.com/file/2020/09/67-d1a9188d.jpg)

修改mysql的密码
![14.jpg](https://b3logfile.com/file/2020/09/14-2db23659.jpg)

最后记得修改你的宝塔面板的账号密码，为了下次登录方便

![77.jpg](https://b3logfile.com/file/2020/09/77-9317b76b.jpg)

**运行环境到这里就装好了！**

下载[bolo](https://github.com/adlered/bolo-solo/releases)，解压
![78.jpg](https://b3logfile.com/file/2020/09/78-c582648a.jpg)

找到这个文件，右键记事本打开
找到并且修改

```
#### MySQL runtime ###
runtimeDatabase=MYSQL
jdbc.username=solo                                            #设置你远程连接的数据库账号
jdbc.password=Hu12345@                                 #设置你远程连接的数据库密码
jdbc.driver=com.mysql.cj.jdbc.Driver
jdbc.URL=jdbc:mysql://x.x.x.x/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC    #将x.x.x.x换成你的公网ip
```

保存

再打开putty，进入命令行界面
打开数据库

```
#登录mysql
mysql -u root -p
```

密码是你在宝塔面板设置的数据库密码

执行命令

```
#创建数据库solo
create database solo;
```

mysql开启远程连接

```
#mysql开启远程连接
GRANT ALL PRIVILEGES ON *.* TO 'solo'@'%' IDENTIFIED BY 'Hu12345@' WITH GRANT OPTION;
```

```
#应用设置
FLUSH PRIVILEGES;
```

数据库准备就绪，当然你可以先去IDEA远程连这个数据库先试试

打开并且进入XFTP

找到这个目录
![555.jpg](https://b3logfile.com/file/2020/09/555-7a38998f.jpg)

删除原来的文件，讲之前下载的文件复制进这里

保险起见，进入宝塔面板重启这些
![22222.jpg](https://b3logfile.com/file/2020/09/22222-bbeb8c40.jpg)

大功告成！
访问你的公网ip：8080
![21121121211211.jpg](https://b3logfile.com/file/2020/09/21121121211211-d5dee6ae.jpg)

设置bolo的管理员账号密码，开始你的个人博客之旅吧

## 后记

鬼知道为啥我建站成功，要写下这篇啥也不是的博文（好像大家第一篇都是这样？）

就当是给自己哪天服务器崩了要重建留个笔记吧，各位就凑合参考看看吧。

😄

