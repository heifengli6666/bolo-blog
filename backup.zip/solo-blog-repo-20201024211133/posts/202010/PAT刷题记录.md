title: 【PAT】刷题记录
date: '2020-10-17 09:43:32'
updated: '2020-10-24 19:47:33'
tags: [PAT, C++]
permalink: /PAT
---
![在这里插入图片描述](https://img-blog.csdnimg.cn/20201024185401485.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2hlaWZlbmdsaTY2NjY=,size_16,color_FFFFFF,t_70#pic_center)

## B1001 害死人不偿命的(3n+1)猜想 (15分)

卡拉兹(Callatz)猜想：

对任何一个正整数 n，如果它是偶数，那么把它砍掉一半；如果它是奇数，那么把 (3n+1) 砍掉一半。这样一直反复砍下去，最后一定在某一步得到 n=1。卡拉兹在 1950 年的世界数学家大会上公布了这个猜想，传说当时耶鲁大学师生齐动员，拼命想证明这个貌似很傻很天真的命题，结果闹得学生们无心学业，一心只证 (3n+1)，以至于有人说这是一个阴谋，卡拉兹是在蓄意延缓美国数学界教学与科研的进展……

我们今天的题目不是证明卡拉兹猜想，而是对给定的任一不超过 1000 的正整数 n，简单地数一下，需要多少步（砍几下）才能得到 n=1？
输入格式：

每个测试输入包含 1 个测试用例，即给出正整数 n 的值。
输出格式：

输出从 n 计算到 1 需要的步数。
输入样例：
3
输出样例：
5
实现代码：

```cpp
#include <iostream>
using namespace std;
int main()
{
    int i=0, set;
    cin >> i;
    for (set = 0;i != 1;set++)
    {
        if (i % 2 == 0)
        {
            i = i / 2;
        }
        else
        {
            i = (3 * i + 1) / 2;
        }
    }
    cout << set;
    system("pause");
    return 0;
}
```

![在这里插入图片描述](https://img-blog.csdnimg.cn/20201024185030360.jpg?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2hlaWZlbmdsaTY2NjY=,size_16,color_FFFFFF,t_70#pic_center)

## B1032 挖掘机技术哪家强 (20分)

为了用事实说明挖掘机技术到底哪家强，PAT 组织了一场挖掘机技能大赛。现请你根据比赛结果统计出技术最强的那个学校。

输入格式：
输入在第 1 行给出不超过 10000 的正整数 N，即参赛人数。随后 N 行，每行给出一位参赛者的信息和成绩，包括其所代表的学校的编号（从 1 开始连续编号）、及其比赛成绩（百分制），中间以空格分隔。

输出格式：
在一行中给出总得分最高的学校的编号、及其总分，中间以空格分隔。题目保证答案唯一，没有并列。

输入样例：
6
3 65
2 80
1 100
2 70
3 40
3 0
输出样例：
2 150
实现代码：

```cpp
#include <iostream>
using namespace std;
#define N 100000
int school[N] = { 0 };//记录每个学校的总分
int main()
{
	int n, schId, score;
	cin >> n;
	for (int i = 0;i < n;i++)
	{
		cin >> schId >> score;//学校ID 和 分数
		school[schId] += score;//学校schID的总分加score
	}
	int k = 1, MAX = -1;//最高分的学校ID以及其总分
	for (int i = 1;i <= n;i++)//选出最高分
	{
		if (school[i] > MAX)
		{
			MAX = school[i];
			k = i;
		}
	}
	cout << k <<" "<< MAX;


	system("pause");
	return 0;
}
```

![在这里插入图片描述](https://img-blog.csdnimg.cn/20201024192654249.jpg?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2hlaWZlbmdsaTY2NjY=,size_16,color_FFFFFF,t_70#pic_center)

## B1036 跟奥巴马一起编程 (15分)

美国总统奥巴马不仅呼吁所有人都学习编程，甚至以身作则编写代码，成为美国历史上首位编写计算机代码的总统。2014 年底，为庆祝“计算机科学教育周”正式启动，奥巴马编写了很简单的计算机代码：在屏幕上画一个正方形。现在你也跟他一起画吧！

输入格式：
输入在一行中给出正方形边长 N（3≤N≤20）和组成正方形边的某种字符 C，间隔一个空格。

输出格式：
输出由给定字符 C 画出的正方形。但是注意到行间距比列间距大，所以为了让结果看上去更像正方形，我们输出的行数实际上是列数的 50%（四舍五入取整）。

输入样例：
10 a
输出样例：
aaaaaaaaaa
a        a
a        a
a        a
aaaaaaaaaa
代码实现：

```cpp
#include <iostream>
using namespace std;
#define N_MAX 20
int N = 0;//正方形边长
char C = 'a';//字符C
int main()
{
	cin >> N >> C;
	for (int i = 0;i < N;i++)//输出最上面的一条边
	{
		cout << C;
	}
	cout << endl;
	if (N % 2 == 0)//N为偶数
	{
		for (int i = 0;i < N / 2 - 2;i++)
		{
			cout << C;
			for (int i = 0;i < N - 2;i++)
			{
				cout << " ";
			}
			cout << C;
			cout << endl;
		}
	}
	else//N为奇数,加1使其为偶数
	{
		for (int i = 0;i < (N+1) / 2 - 2;i++)
		{
			cout << C;
			for (int i = 0;i < N - 2;i++)
			{
				cout << " ";
			}
			cout << C;
			cout << endl;
		}
	}


	for (int i = 0;i < N;i++)//输出最下面的一条边
	{
		cout << C;
	}
	cout << endl;
	system("pause");
	return 0;
}
```

![在这里插入图片描述](https://img-blog.csdnimg.cn/20201024194548697.jpg?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2hlaWZlbmdsaTY2NjY=,size_16,color_FFFFFF,t_70#pic_center)

