title: python-接金币小游戏
date: '2020-09-20 08:11:40'
updated: '2020-11-09 23:40:20'
tags: [赵二狗]
permalink: /articles/2020/09/20/1604899522981.html
---
![在这里插入图片描述](https://img-blog.csdnimg.cn/20201109132105738.jpg?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2hlaWZlbmdsaTY2NjY=,size_16,color_FFFFFF,t_70#pic_center)

## 演示视频

<div style="position: relative; padding: 30% 45%;">
<iframe style="position: absolute; width: 100%; height: 100%; left: 0; top: 0;" src="//player.bilibili.com/player.html?bvid=BV1LA411j7s3&as_wide=1&high_quality=1&danmaku=1" scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true"></iframe>
</div>

## 寓意

小赵天天骑着电瓶车上下班，每天奔迫于生计（奶茶）与爱情（爱心），有时为了爱心会损失奶茶，有时为了奶茶而损失爱心。但是我相信面包会有的，爱情也会有的，祝我家小赵年年18岁！

## 源码

魔改自开源代码：https://github.com/CharlesPikachu/Games

需要此代码，自取：https://gitee.com/black_pineapple_6666/pick-up-the-gold-coin

